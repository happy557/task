from django.test import TestCase
from django.urls import reverse
from django.core.management import call_command
from io import StringIO
from products.models import Product, ProductVariant

class ProductModelTests(TestCase):
    def setUp(self):
        self.product = Product.objects.create(name="Test Product", description="A test product", price=10.00)
        self.variant = ProductVariant.objects.create(product=self.product, color="Red", size="M", additional_price=2.00)

    def test_product_creation(self):
        self.assertEqual(Product.objects.count(), 1)
        self.assertEqual(Product.objects.get(pk=self.product.pk).name, "Test Product")

    def test_product_variant_creation(self):
        self.assertEqual(ProductVariant.objects.count(), 1)
        self.assertEqual(ProductVariant.objects.get(pk=self.variant.pk).color, "Red")

class ProductViewsTests(TestCase):
    def setUp(self):
        self.product = Product.objects.create(name="Test Product", description="A test product", price=10.00)

    def test_product_list_view(self):
        response = self.client.get(reverse('product_list'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Test Product")

    def test_product_detail_view(self):
        response = self.client.get(reverse('product_detail', args=[self.product.pk]))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Test Product")

    def test_product_create_view(self):
        response = self.client.post(reverse('product_create'), {'name': 'New Product', 'description': 'New product description', 'price': 20.00})
        self.assertEqual(response.status_code, 302)  # Redirects after successful creation
        self.assertEqual(Product.objects.count(), 2)

    def test_product_update_view(self):
        response = self.client.post(reverse('product_update', args=[self.product.pk]), {'name': 'Updated Product', 'description': 'Updated description', 'price': 15.00})
        self.assertEqual(response.status_code, 302)  # Redirects after successful update
        self.product.refresh_from_db()
        self.assertEqual(self.product.name, 'Updated Product')

    def test_product_delete_view(self):
        response = self.client.post(reverse('product_delete', args=[self.product.pk]))
        self.assertEqual(response.status_code, 302)  # Redirects after successful deletion
        self.assertEqual(Product.objects.count(), 0)

class ProductVariantViewsTests(TestCase):
    def setUp(self):
        self.product = Product.objects.create(name="Test Product", description="A test product", price=10.00)
        self.variant = ProductVariant.objects.create(product=self.product, color="Red", size="M", additional_price=2.00)

    def test_product_variant_list_view(self):
        response = self.client.get(reverse('product_variant_list'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Test Product - Red - M")

    def test_product_variant_detail_view(self):
        response = self.client.get(reverse('product_variant_detail', args=[self.variant.pk]))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Red - M")

    def test_product_variant_create_view(self):
        response = self.client.post(reverse('product_variant_create'), {'product': self.product.pk, 'color': 'Blue', 'size': 'L', 'additional_price': 3.00})
        self.assertEqual(response.status_code, 302)  # Redirects after successful creation
        self.assertEqual(ProductVariant.objects.count(), 2)

    def test_product_variant_update_view(self):
        response = self.client.post(reverse('product_variant_update', args=[self.variant.pk]), {'product': self.product.pk, 'color': 'Green', 'size': 'L', 'additional_price': 4.00})
        self.assertEqual(response.status_code, 302)  # Redirects after successful update
        self.variant.refresh_from_db()
        self.assertEqual(self.variant.color, 'Green')

    def test_product_variant_delete_view(self):
        response = self.client.post(reverse('product_variant_delete', args=[self.variant.pk]))
        self.assertEqual(response.status_code, 302)  # Redirects after successful deletion
        self.assertEqual(ProductVariant.objects.count(), 0)

class DataLoadingTests(TestCase):
    def setUp(self):
        self.product = Product.objects.create(name="Test Product", description="A test product", price=10.00)
        self.variant = ProductVariant.objects.create(product=self.product, color="Red", size="M", additional_price=2.00)

    def test_load_product_data_command(self):
        out = StringIO()
        call_command('load_product_data', stdout=out)
        output = out.getvalue()

        self.assertIn("Product: Test Product - $10.00", output)
        self.assertIn("  Variant: Red - M - $2.00", output)
