# products/management/commands/load_product_data.py
from django.core.management.base import BaseCommand
from products.models import Product, ProductVariant

class Command(BaseCommand):
    help = 'Load and display product data'

    def handle(self, *args, **kwargs):
        products = Product.objects.all()
        for product in products:
            self.stdout.write(f"Product: {product.name} - ${product.price:.2f}")
            variants = ProductVariant.objects.filter(product=product)
            for variant in variants:
                self.stdout.write(f"  Variant: {variant.color} - {variant.size} - ${variant.additional_price:.2f}")
